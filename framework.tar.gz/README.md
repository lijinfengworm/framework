#jblog

个人博客，部署在SAE:[www.code4awesome.com](http://www.code4awesome.com),   
使用[https://github.com/michaelliao/awesome-python-webapp](https://github.com/michaelliao/awesome-python-webapp)
的简易Web开发框架.  


Features:

1. 添加了分类标签。
2. Markdown编辑器。
3. 集成了Mathjax公式库。
4. Sae上传功能。

deploy on sae:

1. Modify uyan review system's parameters which key name is review in config_default.py .
2. Create storage service in SAE and rewrite your bucket name in config_default.py.
3. Create mysql service in SAE,then source sql script in jblog database.
4. Create kvdb service in SAE.
5. Create sequential taskQueue service in SAE and rewrite your taskqueue name in config_default.py.




configs = {
    'db':{
        'host':'192.168.9.104',
        'port':3306,
        'user':'kaluli',
        'password':'kaluli',
        'database':'test'
    }, 
    'session':{
        'secret':'AwEsOmE'    
    },
    'review':{
        'domain':'code4awesome.sinaapp.com',
        'url':'http://v2.uyan.cc/code/uyan.js?uid=2011427'
        },
    'storage':{
        'bucket':'code4awesome'
        },
    'taskqueue':'counter'
        
}
